var searchData=
[
  ['copy',['Copy',['../class_copy.html',1,'']]],
  ['copydialog',['CopyDialog',['../class_copy_dialog.html',1,'']]]
];
