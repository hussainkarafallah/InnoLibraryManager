var searchData=
[
  ['user',['user',['../class_document_view.html#ae1263eed83465e5d66e436bd62756b19',1,'DocumentView']]]
];
