var searchData=
[
  ['notification',['Notification',['../class_notification.html',1,'']]],
  ['notificationswidget',['NotificationsWidget',['../class_notifications_widget.html',1,'']]]
];
