var searchData=
[
  ['updatecopy',['updateCopy',['../class_document_data_proxy.html#ae020e080886dc584866ba00429fc0d2b',1,'DocumentDataProxy']]],
  ['updatedata',['updateData',['../class_librarian_copy_model.html#a8db16685162cbece57dac146e272629a',1,'LibrarianCopyModel::updateData()'],['../class_user_copy_model.html#a2a55584b0bff29b727095a0138f98d89',1,'UserCopyModel::updateData()']]],
  ['updatedataawuser',['updateDataAWUser',['../class_librarian_copy_model.html#a134365034d48f25385918ac93ace5407',1,'LibrarianCopyModel']]],
  ['updatedocument',['updateDocument',['../class_document_data_proxy.html#a31624689e360554c9d65029d2daa692a',1,'DocumentDataProxy::updateDocument()'],['../class_document_model.html#ad0532b55bfdd148eff220278d0109f2a',1,'DocumentModel::updateDocument()']]],
  ['updaterequest',['updateRequest',['../class_document_view.html#a288eb029e733943ea9b71e3a9f68e85b',1,'DocumentView::updateRequest()'],['../class_document_view.html#a288eb029e733943ea9b71e3a9f68e85b',1,'DocumentView::updateRequest()'],['../class_user_model_view.html#ab8c5ecc3d408ba9fe0d2926513dfb5ad',1,'UserModelView::updateRequest()']]],
  ['updaterequesthandler',['updateRequestHandler',['../class_document_manager_widget.html#a50b9aefa1c52b312a19d713586c878e6',1,'DocumentManagerWidget::updateRequestHandler()'],['../class_user_manager_widget.html#a8012475fa4364576665f3a04c78216da',1,'UserManagerWidget::updateRequestHandler()']]],
  ['updateuser',['updateUser',['../class_user_data_proxy.html#a11363a4f7ddcc9f6b4c4d6b0e02cd0a7',1,'UserDataProxy::updateUser()'],['../class_user_model.html#acf04bd62cd834628330eee459d243343',1,'UserModel::updateUser()']]],
  ['usercopymanager',['UserCopyManager',['../class_user_copy_manager.html#ae3c3f2d31d17e3f4467703b093cd6f48',1,'UserCopyManager::UserCopyManager(QWidget *parent=nullptr)'],['../class_user_copy_manager.html#ae3a1c949ec114c07ed33e4cbaf351923',1,'UserCopyManager::UserCopyManager(QWidget *parent, User *U)']]],
  ['usercopymodel',['UserCopyModel',['../class_user_copy_model.html#abf267e6685cb07ca237bf015550b56e3',1,'UserCopyModel']]],
  ['usercopyview',['UserCopyView',['../class_user_copy_view.html#ac5eb4abc86c8ab875cb30a8a40d5b28b',1,'UserCopyView']]],
  ['userdataproxy',['UserDataProxy',['../class_user_data_proxy.html#a412242725c369bc2049a7cd700b21c2d',1,'UserDataProxy']]],
  ['userdatarequesthandler',['userDataRequestHandler',['../class_user_manager_widget.html#a75440e3c0584cec4c73426a45ebc8df5',1,'UserManagerWidget']]],
  ['userinforequesthandler',['userInfoRequestHandler',['../class_librarian_copy_manager.html#add7d1d65f942442329aee1684a8f8c39',1,'LibrarianCopyManager']]],
  ['usermodelview',['UserModelView',['../class_user_model_view.html#a0a18a1d90e855e899948d51ce91e1b1b',1,'UserModelView']]],
  ['userwindow',['UserWindow',['../class_user_window.html#a52624af72556f56d5843df34dd4303cb',1,'UserWindow']]]
];
