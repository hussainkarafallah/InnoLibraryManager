var searchData=
[
  ['librariancopymanager',['LibrarianCopyManager',['../class_librarian_copy_manager.html#a2764be1ae1b542625a585a6656116331',1,'LibrarianCopyManager::LibrarianCopyManager(QWidget *parent=nullptr)'],['../class_librarian_copy_manager.html#ae7b4330a6d97aa614f4281aba15aca3b',1,'LibrarianCopyManager::LibrarianCopyManager(QWidget *parent, User *U)']]],
  ['librariancopymodel',['LibrarianCopyModel',['../class_librarian_copy_model.html#aa2f3e68d3a207a9f2b2aa2dc5d217f00',1,'LibrarianCopyModel']]],
  ['librariancopyview',['LibrarianCopyView',['../class_librarian_copy_view.html#a0730ff8acadf3f93a85363675231e740',1,'LibrarianCopyView']]],
  ['librarianwindow',['LibrarianWindow',['../class_librarian_window.html#a435809959da79adecb6eec4810fb0f89',1,'LibrarianWindow']]],
  ['logout',['logOut',['../class_user_window.html#a2b80a934088284ba07db59affb44c818',1,'UserWindow']]]
];
