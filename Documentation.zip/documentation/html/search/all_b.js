var searchData=
[
  ['patron',['Patron',['../class_patron.html',1,'']]],
  ['performbooking',['performBooking',['../class_document_data_proxy.html#a1d863325fde428ad74313f3a4a8c5eac',1,'DocumentDataProxy']]],
  ['performimmediatereturn',['performImmediateReturn',['../class_document_data_proxy.html#acb3d65909af6f20a13ee013ab7c058d5',1,'DocumentDataProxy']]],
  ['performreturn',['performReturn',['../class_document_data_proxy.html#a6f56fb120760c36d6cd5b8d418931814',1,'DocumentDataProxy']]],
  ['placeinqueue',['placeInQueue',['../class_document_data_proxy.html#abdbad4b29866e99ad8b90be216b966c8',1,'DocumentDataProxy']]],
  ['placeoutstandingrequest',['placeOutstandingRequest',['../class_document_data_proxy.html#a2868537b338497183018db75c1b3b69b',1,'DocumentDataProxy']]],
  ['professor',['Professor',['../class_professor.html',1,'']]]
];
