var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'']]],
  ['model',['model',['../class_document_view.html#adcfe5927407134f9d11aee35c0a363ef',1,'DocumentView']]]
];
