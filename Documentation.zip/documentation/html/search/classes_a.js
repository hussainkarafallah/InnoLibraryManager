var searchData=
[
  ['patron',['Patron',['../class_patron.html',1,'']]],
  ['professor',['Professor',['../class_professor.html',1,'']]]
];
