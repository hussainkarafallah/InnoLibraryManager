var searchData=
[
  ['validate',['validate',['../class_add_dialog__av.html#abcd90b9c3e67e222239d0d0b4186c572',1,'AddDialog_av::validate()'],['../class_add_dialog__book.html#afa52342cb606ac0783c9247e1b3e777e',1,'AddDialog_book::validate()'],['../class_add_dialog__docs.html#a2e773764cd7b7e45bc34d8a2d1352e03',1,'AddDialog_docs::validate()'],['../class_add_dialog__journal_article.html#ae1989387d8f9b68bda661fd85c768f3f',1,'AddDialog_journalArticle::validate()']]],
  ['view',['view',['../class_document_view.html#a1b97679120b4ff1dacae577ac5d357ed',1,'DocumentView::view()'],['../class_user_model_view.html#a88a9b0105635511ac6afda69bdf20202',1,'UserModelView::view()']]],
  ['viewbuttonclicked',['viewButtonClicked',['../class_document_view.html#a105113ccf4daf056d63023ec3b064a33',1,'DocumentView::viewButtonClicked()'],['../class_document_view.html#a105113ccf4daf056d63023ec3b064a33',1,'DocumentView::viewButtonClicked()']]],
  ['viewdialog_5fav',['ViewDialog_av',['../class_view_dialog__av.html',1,'']]],
  ['visitingprofessor',['VisitingProfessor',['../class_visiting_professor.html',1,'']]]
];
