var searchData=
[
  ['copydialog',['copyDialog',['../class_document_view.html#ab6d8eafbc09872bba605ec5bc278730e',1,'DocumentView']]]
];
