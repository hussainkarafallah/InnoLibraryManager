var searchData=
[
  ['view',['view',['../class_document_view.html#a1b97679120b4ff1dacae577ac5d357ed',1,'DocumentView::view()'],['../class_user_model_view.html#a88a9b0105635511ac6afda69bdf20202',1,'UserModelView::view()']]]
];
