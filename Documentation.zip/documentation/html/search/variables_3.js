var searchData=
[
  ['typedialog',['typeDialog',['../class_document_view.html#a70a20d2c6d3c1a72ff54a4a2a5659b10',1,'DocumentView']]]
];
