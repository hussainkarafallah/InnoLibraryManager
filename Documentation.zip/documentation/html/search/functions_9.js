var searchData=
[
  ['newnotifications',['newNotifications',['../class_notifications_widget.html#a043f630928b9eafc27f48f00b6f5d8b8',1,'NotificationsWidget']]]
];
